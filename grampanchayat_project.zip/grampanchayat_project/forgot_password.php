<?php
require_once 'config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    
    if (empty($email)) {
        $error = 'Please enter your registered email address';
    } else {
        $conn = getDBConnection();
        
        // Check if email exists
        $stmt = $conn->prepare("SELECT ResidentID, Residents_Name FROM residents WHERE Email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            
            // Generate reset token (in a real app, this would be more secure)
            $token = bin2hex(random_bytes(32));
            $expires = date("Y-m-d H:i:s", strtotime('+1 hour'));
            
            // Store token in database
            $updateStmt = $conn->prepare("UPDATE residents SET ResetToken = ?, ResetExpires = ? WHERE ResidentID = ?");
            $updateStmt->bind_param("ssi", $token, $expires, $user['ResidentID']);
            $updateStmt->execute();
            
            if ($updateStmt->affected_rows == 1) {
                // In a real application, you would send an email here
                $resetLink = "http://" . $_SERVER['HTTP_HOST'] . "/reset_password.php?token=$token";
                
                // For demo purposes, we'll just show the link
                $success = "Password reset link has been generated. <a href='$resetLink'>Click here to reset your password</a>";
            } else {
                $error = 'Error generating reset token';
            }
            
            $updateStmt->close();
        } else {
            $error = 'Email address not found in our system';
        }
        
        $stmt->close();
        closeDBConnection($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Rural Development Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome@6.4.0/css/all.min.css">
    <style>
        /* Reuse styles from login.php */
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-bg);
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        
        .login-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .login-container {
            max-width: 500px;
            margin: 3rem auto;
            padding: 2rem;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .login-title {
            color: var(--primary-color);
            font-weight: 700;
            margin-bottom: 1.5rem;
            text-align: center;
            position: relative;
        }
        
        .login-title::after {
            content: '';
            display: block;
            width: 60px;
            height: 4px;
            background: var(--accent-color);
            margin: 10px auto;
            border-radius: 2px;
        }
        
        .btn-primary {
            background-color: var(--secondary-color);
            border: none;
        }
        
        .btn-primary:hover {
            background-color: #2980b9;
        }
        
        .login-footer {
            background-color: var(--primary-color);
            color: white;
            padding: 1.5rem;
            text-align: center;
            margin-top: auto;
        }
        
        .alert {
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <header class="login-header">
        <div class="container">
            <div class="d-flex justify-content-center align-items-center">
                <img src="https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg" 
                     alt="Government symbol" height="60" class="me-3">
                <div>
                    <h2>Maharashtra Rural Development Department</h2>
                    <p class="mb-0">Resident Portal</p>
                </div>
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Seal_of_Maharashtra.svg/1200px-Seal_of_Maharashtra.svg.png" 
                     alt="Government symbol" height="60" class="ms-3">
            </div>
        </div>
    </header>
    
    <main class="flex-grow-1">
        <div class="container">
            <div class="login-container">
                <h1 class="login-title">Forgot Password</h1>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <form action="forgot_password.php" method="POST">
                    <div class="mb-3">
                        <label for="email" class="form-label">Registered Email Address</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                        <div class="form-text">We'll send a password reset link to this email</div>
                    </div>
                    
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">Reset Password</button>
                    </div>
                </form>
                
                <div class="mt-3 text-center">
                    <a href="login.php" class="text-decoration-none">Back to Login</a>
                </div>
            </div>
        </div>
    </main>
    
    <footer class="login-footer">
        <div class="container">
            <p class="mb-0">© 2024. Content owned and maintained by Rural Development & Panchayat Raj Department, Government of Maharashtra, India.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>