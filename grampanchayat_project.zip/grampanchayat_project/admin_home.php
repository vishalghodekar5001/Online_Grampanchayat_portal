<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "grampanchayt";

$conn = mysqli_connect($server, $username, $password, $database);
if ($conn) {
    // Query to get total number of users
    $totalUsersQuery = "SELECT COUNT(*) as totalUsers FROM `login_accounts`";
    $totalUsersResult = mysqli_query($conn, $totalUsersQuery);
    $totalUsersRow = mysqli_fetch_assoc($totalUsersResult);
    $totalUsers = $totalUsersRow['totalUsers'];

    // Query to get total number of registered properties
    $totalPropertiesQuery = "SELECT COUNT(*) as totalProperties FROM `registered_properties`";
    $totalPropertiesResult = mysqli_query($conn, $totalPropertiesQuery);
    $totalPropertiesRow = mysqli_fetch_assoc($totalPropertiesResult);
    $totalregisteredProperties = $totalPropertiesRow['totalProperties'];
} else {
    die(mysqli_connect_error());
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
            font-family: 'Poppins', sans-serif;
        }

        .sidebar {
            height: 100vh;
            background-color: #343a40;
            color: white;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 15px;
            transition: background 0.3s;
        }

        .sidebar a:hover {
            background: #495057;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .header img {
            height: 80px;
        }

        .stat {
            font-size: 2.5rem;
            font-weight: bold;
        }

        .title {
            font-size: 1.2rem;
            margin-top: 10px;
        }
    </style>
</head>

<body>

    <div class="d-flex">
        <div class="sidebar p-3">
            <h4 class="text-center">Admin Panel</h4>
            <a href="dashboard.php"><i class="fas fa-home me-2"></i> Dashboard</a>
            <a href="future.html"><i class="fas fa-users me-2"></i> Manage Citizens</a>
            <a href="check_database.php"><i class="fas fa-database me-2"></i> Check Database</a>
            <a href="check_propertyRegistrations.php"><i class="fas fa-building me-2"></i> Property Registrations</a>
            <a href="generate_bill.php"><i class="fas fa-file-invoice me-2"></i> Generate Bill</a>
            <a href="future.html"><i class="fas fa-receipt me-2"></i> Generate Receipt</a>
            <a href="#"><i class="fas fa-concierge-bell me-2"></i> Service Requests</a>
            <a href="#"><i class="fas fa-exclamation-triangle me-2"></i> Complaints</a>
            <a href="#"><i class="fas fa-newspaper me-2"></i> Notices</a>
            <a href="#"><i class="fas fa-project-diagram me-2"></i> Projects</a>
            <a href="#"><i class="fas fa-coins me-2"></i> Tax Management</a>
            <a href="#"><i class="fas fa-chart-line me-2"></i> Budget Management</a>
            <a href="#"><i class="fas fa-cogs me-2"></i> Admin Settings</a>
            <a href="#"><i class="fas fa-file-alt me-2"></i> Reports</a>
        </div>

        <!-- Main Content -->
        <div class="flex-grow-1">
            <!-- Navbar -->
            <nav class="navbar navbar-expand navbar-light bg-white p-3">
                <div class="container-fluid">
                    <span class="navbar-brand">Dashboard</span>
                    <div class="ms-auto d-flex align-items-center">
                        <span class="me-3">Welcome, Admin</span>
                        <a href="logout.php" class="btn btn-outline-danger btn-sm">Logout</a>
                        </div>
                </div>
            </nav>
            <!-- Page Content -->
            <div class="content">
                <div class="row g-4 mb-4">
                    <div class="col-md-3">
                        <div class="card p-3 text-center">
                            <h5>Citizens</h5>
                            <h2>1200</h2>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card p-3 text-center">
                            <h5>Pending Requests</h5>
                            <h2>25</h2>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card p-3 text-center">
                            <h5>Open Complaints</h5>
                            <h2>12</h2>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card p-3 text-center">
                            <h5>Tax Collected</h5>
                            <h2>₹5L</h2>
                        </div>
                    </div>
                </div>
                <div class="flex-grow-1 p-4">


                    <div class="row g-4">
                        <div class="col-md-6">
                            <div class="card text-white bg-primary">
                                <div class="card-body text-center">
                                    <div class="stat"><?php echo $totalUsers; ?></div>
                                    <div class="title">Total Users</div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="card text-white bg-success">
                                <div class="card-body text-center">
                                    <div class="stat"><?php echo $totalregisteredProperties; ?></div>
                                    <div class="title">Total Property Registrations</div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="card text-white bg-warning">
                                <div class="card-body text-center">
                                    <div class="stat">$</div>
                                    <a href="generate_bill.php"></a>
                                    <div class="title">Generate Bill</div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="card text-white bg-danger">
                                <div class="card-body text-center">
                                    <div class="stat">$</div>
                                    <div class="title">Generate Receipt</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>