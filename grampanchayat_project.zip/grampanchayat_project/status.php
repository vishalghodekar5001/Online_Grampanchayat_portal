<!-- 

<!DOCTYPE html>
<html>
    <head>
		<title>Bootstrap Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
		<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
		<link rel="stylesheet" href="status.css">

		

    </head>

    <body>
		 
		<header class="header">
			<img src="https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg" alt="Government symbol">
			<div class="image">
				<img style="width:1100px"; height="100%" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8MWORO6pzmivILU-Pbm-LrZuB-Tt2dhatYwNIkOLWocFxqEsrrr-DwSd6M7R0hMYpiw&usqp=CAU">
	
			</div>
			<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Seal_of_Maharashtra.svg/1200px-Seal_of_Maharashtra.svg.png" alt="Government symbol">
		</header>
   		<nav>
      		<ul>
        		<li><a href="home.html">Home</a></li>
       			<li><a href="about.html">About us</a></li>
        		<li><a href="schames.html">Scheme</a></li>
        		<li><a href="contact.html">Contact</a></li>
        		<li><a href="viewstatus.php">Check Status</a></li>
        		<li><a href="login.php">Login</a></li>
      		</ul>
			  <a href="logout.php"><button type="button" class="btn  btn-danger" >Logout</button></a>

    	</nav>





	<form>
		<div class="container">
			<label for="houseID">House ID</label>
			<input type="text" id="houseID" name="houseID" placeholder="Enter your house ID" required>

			<label for="mobile">Mobile Number</label>
			<input type="text" id="mobile" name="mobile" placeholder="Enter your mobile number" required>

			<button type="button" onclick="showOTP()">Generate OTP</button>

			<div class="otp-container" id="otpContainer">
				<label for="otp">Enter OTP</label>
				<input type="password" id="otp" name="otp" placeholder="Enter the OTP you received" required>
			</div>

			<button  type="submit">Submit</button>
		</div>
	</form>

	<script>
		function showOTP() {
			document.getElementById("otpContainer").classList.add("show");
		}
	</script>




	<div class="footer">
		<div class="container">
		<div class="row">
		<div id="FooterMenu1_Footermenu1" style="text-align:center;">
		  <a href="/en/Policies-and-Disclaimers"> Disclaimers</a> | <a href="/en/content/website-polices">  Website Polices</a> |<a href="/en/Sitemap">Sitemap</a> | <a href="/en/help">Help</a> | <a href="/en/Usefulness"> Accssibility Statement</a> | <a href="/en/Terms-and-Conditions">Terms and Conditions</a> | <a href="contact-us">Contact</a> | <a href="/en/feedback-form">Feedback</a> | <a href="/en/archive">Archive</a> | <a href="/en/tenders">Tenders</a> | <a href="/en/recruitment ">Recruitment</a> | <a href="/en/services">Services</a>  
		</div>
		<div style="text-align:center;" tabindex="0">© 2017.Content available on website is owned and maintained by Rural Development &amp; Panchayat Raj Department, Government of Maharashtra, India.</div>
		</div>
		<p style="text-align:center;" class="focus-link" tabindex="0">
		 Last Update  : 18-Nov-2022 1:43 pm         |   Visitor Counter : 11168614     |  Todays Visitor Counter: 7858</p>
		<p style="text-align:center;" class="focus-link" tabindex="0">Developed by:<a href="http://terasoft.in" target="_blank">Terasoft Technologies</a>, Maharashtra (India) </p>
		<div class="parag" style="text-align:center;  margin-top: 0.5em;  margin-bottom: 1.5em;">
			<a href="https://achecker.ca/checker/index.php?uri=referer&amp;gid=WCAG2-AA" title="WCAG 2.0 (Level AA)" target="_blank">
			  <img src="/images/icon_W2_aa.jpg" alt="WCAG 2.0 (Level AA)" title="WCAG 2.0 (Level AA)" longdesc="https://achecker.ca/checker/index.php?uri=referer&amp;gid=WCAG2-AA">
			</a>
		
			<a href="https://www.w3.org/WAI/WCAG2AA-Conformance" title="Explanation of WCAG 2.0 Level Double-A Conformance" target="_blank">
			  <img src="https://www.w3.org/WAI/wcag2AA" alt="W3C WAI Web" title="Level Double-A conformance,W3C WAI Web Content Accessibility Guidelines 2.0" longdesc="https://www.w3.org/WAI/WCAG2AA-Conformance" style="width: 6.7em;">
			</a>
		
			<a href="https://validator.w3.org/check?uri=referer" title="Valid XHTML 1.0 Transitional" target="_blank">
				<img src="https://www.w3.org/Icons/valid-xhtml10" alt="Valid XHTML 1.0 Transitional" title="Valid XHTML 1.0 Transitional" longdesc="https://validator.w3.org/check?uri=referer">
			</a>
		
			<a href="https://jigsaw.w3.org/css-validator/check/referer" title="Valid CSS!" target="_blank">
				<img src="/images/vcss.gif" alt="Valid CSS!" title="Valid CSS" longdesc="https://jigsaw.w3.org/css-validator/check/referer">
			</a>
		</div>
		</div>
		</div>
    </body>
</html>  -->










<?php
    $server="localhost";
    $username="root";
    $password="";
    $database="grampanchayt";

    $conn=mysqli_connect($server,$username,$password,$database);
    if($conn)
    {
        $found=false;
        if($_SERVER["REQUEST_METHOD"]=="POST")
        {
            $House_id=$_POST["house_id"];
            $owner_name=$_POST['owner_name'];
            $email=$_POST["mail"];

            $gram_id=0;
            $house_type=" ";
            $house_amount=0;
            $water_amount=0;

            $sql="SELECT * FROM `bill_details` WHERE HouseId='$House_id' AND Email='$email' AND Owner_Name='$owner_name'";
            $result=mysqli_query($conn, $sql);
            if($result)
            {
                
                $found=true;
                while($row=mysqli_fetch_assoc($result))
                {
                    $gram_id=$row['GramId'];
                    $house_type=$row['House_type'];
                    $house_amount=$row['House_amount'];
                    $water_amount=$row['Water_amount'];
                }
                
            }
        }
    }
    else {
        die(mysqli_connect_error());
    }
?>
<!DOCTYPE html>
<html>
    <head>
		<title>Bootstrap Example</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
		<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
		<link rel="stylesheet" href="status.css">
    <link rel="stylesheet" href="style.css">
    </head>

    <body>
		 
	<header class="header">
			<img src="https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg" alt="Government symbol">
			<div class="image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8MWORO6pzmivILU-Pbm-LrZuB-Tt2dhatYwNIkOLWocFxqEsrrr-DwSd6M7R0hMYpiw&usqp=CAU">
	
			</div>
			<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Seal_of_Maharashtra.svg/1200px-Seal_of_Maharashtra.svg.png" alt="Government symbol">
		</header>
   		<nav>
      		<ul>
        		<li><a href="home.html">Home</a></li>
       			<li><a href="about.html">About us</a></li>
        		<li><a href="schames.html">Scheme</a></li>
        		<li><a href="contact.html">Contact</a></li>
				<li><a href="viewstatus.php">Check Status</a></li>
        		<li><a href="login.php">Login</a></li>
      		</ul>

    	</nav>
       
  <div class="container">
    <h1 style="margin-left: 450px";>Check Bill</h1>
    <form method="post" action="">
      <label for="house_id">House ID:</label>
      <input type="text" id="house_id" name="house_id" required>
      <label for="owner_name">Owner Name:</label>
      <input type="text" id="owner_name" name="owner_name" required> 
      <label for="mail">Email Id:</label>
      <input type="email" id="mail" name="mail" required>  
      <button class="btn btn-success btn-sm" target="parent">Check</button>
    </form>
</div>
</div>
  <div style="text-align:center;margin-left:250px;">
    <?php
        if($found)
        {
          echo "
            <table border='3' border-collapse='collapse' cellspacing='8' cellpadding='8'>
              <tr>
                <th>GramId</th>
                <th>HouseId</th>
                <th>Email Id</th>
                <th>Owner_Name</th>
                <th>House_amount</th>
                <th>Water_amount</th>
                <th>house_type</th>
              </tr>
              <tr>
                <th>$gram_id</th>
                <th>$House_id</th>
                <th>$email</th>
                <th>$owner_name</th>
                <th>$house_amount</th>
                <th>$water_amount</th>
                <th>$house_type</th>
              </tr>
            </table>
          ";
        }
      ?>
    </div>
	  <div class="footer">
		<div class="container">
		<div class="row">
		<div id="FooterMenu1_Footermenu1" style="text-align:center;">
		  <a href="/en/Policies-and-Disclaimers"> Disclaimers</a> | <a href="/en/content/website-polices">  Website Polices</a> |<a href="/en/Sitemap">Sitemap</a> | <a href="/en/help">Help</a> | <a href="/en/Usefulness"> Accssibility Statement</a> | <a href="/en/Terms-and-Conditions">Terms and Conditions</a> | <a href="contact-us">Contact</a> | <a href="/en/feedback-form">Feedback</a> | <a href="/en/archive">Archive</a> | <a href="/en/tenders">Tenders</a> | <a href="/en/recruitment ">Recruitment</a> | <a href="/en/services">Services</a>  
		</div>
		<div style="text-align:center;" tabindex="0">© 2017.Content available on website is owned and maintained by Rural Development &amp; Panchayat Raj Department, Government of Maharashtra, India.</div>
		</div>
		<p style="text-align:center;" class="focus-link" tabindex="0">
		 Last Update  : 18-Nov-2022 1:43 pm         |   Visitor Counter : 11168614     |  Todays Visitor Counter: 7858</p>
		<p style="text-align:center;" class="focus-link" tabindex="0">Developed by:<a href="http://terasoft.in" target="_blank">Terasoft Technologies</a>, Maharashtra (India) </p>
		<div class="parag" style="text-align:center;  margin-top: 0.5em;  margin-bottom: 1.5em;">
			<a href="https://achecker.ca/checker/index.php?uri=referer&amp;gid=WCAG2-AA" title="WCAG 2.0 (Level AA)" target="_blank">
			  <img src="/images/icon_W2_aa.jpg" alt="WCAG 2.0 (Level AA)" title="WCAG 2.0 (Level AA)" longdesc="https://achecker.ca/checker/index.php?uri=referer&amp;gid=WCAG2-AA">
			</a>
		
			<a href="https://www.w3.org/WAI/WCAG2AA-Conformance" title="Explanation of WCAG 2.0 Level Double-A Conformance" target="_blank">
			  <img src="https://www.w3.org/WAI/wcag2AA" alt="W3C WAI Web" title="Level Double-A conformance,W3C WAI Web Content Accessibility Guidelines 2.0" longdesc="https://www.w3.org/WAI/WCAG2AA-Conformance" style="width: 6.7em;">
			</a>
		
			<a href="https://validator.w3.org/check?uri=referer" title="Valid XHTML 1.0 Transitional" target="_blank">
				<img src="https://www.w3.org/Icons/valid-xhtml10" alt="Valid XHTML 1.0 Transitional" title="Valid XHTML 1.0 Transitional" longdesc="https://validator.w3.org/check?uri=referer">
			</a>
		
			<a href="https://jigsaw.w3.org/css-validator/check/referer" title="Valid CSS!" target="_blank">
				<img src="/images/vcss.gif" alt="Valid CSS!" title="Valid CSS" longdesc="https://jigsaw.w3.org/css-validator/check/referer">
			</a>
		</div>
		</div>
		</div>
    </body>
</html> 