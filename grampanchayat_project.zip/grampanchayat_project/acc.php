<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "grampanchayt";
$conn = mysqli_connect($server, $username, $password, $database);

if (!$conn) {
  die(mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $Residents_Name = $_POST["Residents_Name"];
  $email = $_POST["email"];
  $mobile_number = $_POST["mobile_number"];
  $password = $_POST["password"];
  $confirm_password = $_POST["confirm_password"];
  $user_type = $_POST["user_type"];

  if ($password !== $confirm_password) {
    echo "<script>alert('Passwords do not match!');</script>";
  } else {
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO login_accounts (Residents_Name, email, mobile_number, Password, user_type) VALUES (?, ?, ?, ?, ?)");
    if ($stmt) {
      $stmt->bind_param("sssss", $Residents_Name, $email, $mobile_number, $hashed_password, $user_type);
      if ($stmt->execute()) {
        echo "<script>alert('Account created successfully! Please login now.'); window.location.href='login.php';</script>";
      } else {
        echo "<script>alert('Something went wrong while creating the account.');</script>";
      }
    } else {
      echo "<script>alert('Database error: could not prepare statement');</script>";
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Gram Panchayat - Create Account</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
  <style>
    /* SAME STYLE as your login page */
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f5f7fa;
      color: #12263f;
    }
    .header {
      background: linear-gradient(135deg, #12263f 0%, #2c7be5 100%);
      color: white;
      padding: 15px 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .header img {
      height: 60px;
      margin: 0 20px;
    }
    nav {
      background-color: #2c7be5;
      padding: 10px 0;
    }
    nav ul {
      list-style: none;
      display: flex;
      justify-content: center;
      margin: 0;
      padding: 0;
    }
    nav li {
      margin: 0 15px;
    }
    nav a {
      color: white;
      text-decoration: none;
      font-weight: 500;
      padding: 5px 10px;
      border-radius: 4px;
      transition: all 0.3s;
    }
    nav a:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }
    .container {
      max-width: 500px;
      margin: 40px auto;
    }
    .login-page {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
      overflow: hidden;
    }
    .login-header {
      background: linear-gradient(135deg, #2c7be5 0%, #00d97e 100%);
      color: white;
      padding: 20px;
      text-align: center;
    }
    .login-header h3 {
      margin: 0;
      font-weight: 600;
    }
    .form {
      padding: 30px;
    }
    input, select {
      width: 100%;
      padding: 12px 15px;
      margin: 8px 0;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-family: 'Poppins', sans-serif;
      transition: all 0.3s;
    }
    input:focus, select:focus {
      border-color: #2c7be5;
      box-shadow: 0 0 0 3px rgba(44, 123, 229, 0.2);
      outline: none;
    }
    button {
      background: linear-gradient(135deg, #2c7be5 0%, #00d97e 100%);
      color: white;
      border: none;
      padding: 12px;
      width: 100%;
      border-radius: 4px;
      cursor: pointer;
      font-weight: 500;
    }
    button:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
    footer {
      background-color: #12263f;
      color: white;
      padding: 20px 0;
      text-align: center;
      margin-top: 40px;
    }
  </style>
</head>

<body>
  <header class="header">
    <img src="https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg" alt="Government symbol">
    <div class="image">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8MWORO6pzmivILU-Pbm-LrZuB-Tt2dhatYwNIkOLWocFxqEsrrr-DwSd6M7R0hMYpiw&usqp=CAU" alt="Maharashtra Government">
    </div>
    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Seal_of_Maharashtra.svg/1200px-Seal_of_Maharashtra.svg.png" alt="Government symbol">
  </header>

  <nav>
    <ul>
      <li><a href="home.html">Home</a></li>
      <li><a href="#">About</a></li>
      <li><a href="#">Services</a></li>
      <li><a href="#">Contact</a></li>
    </ul>
  </nav>

  <div class="container">
    <div class="login-page">
      <div class="login-header">
        <h3>Create Account</h3>
      </div>
      <div class="form">
        <form action="acc.php" method="post" autocomplete="off">
          <input type="text" name="Residents_Name" placeholder="Full Name" required>
          <input type="email" name="email" placeholder="Email Address" required>
          <input type="text" name="mobile_number" placeholder="Mobile Number" required>
          <input type="password" name="password" placeholder="Password" required>
          <input type="password" name="confirm_password" placeholder="Confirm Password" required>
          <select name="user_type" required>
            <option value="User" selected>User</option>
            <option value="Admin">Admin-Officer</option>
          </select>
          <button type="submit" style="margin-top: 20px;">Register</button>
          <p class="message">Already have an account? <a href="login.php">Login</a></p>
        </form>
      </div>
    </div>
  </div>

  <footer>
    © 2024. Content owned by Rural Development & Panchayat Raj Department, Maharashtra Government.
  </footer>
</body>

</html>
