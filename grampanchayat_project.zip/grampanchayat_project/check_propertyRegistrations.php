<?php
session_start();
if (!isset($_SESSION['Residents_Name'])) {
    header("Location: login.php");
    exit();
}
$Residents_Name = $_SESSION['Residents_Name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Same head content as dashboard.php -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register New Property</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            color: #333;
        }

        .container {
            margin-top: 30px;
        }

        .form-container {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 2rem;
            max-width: 800px;
            margin: 0 auto;
        }

        .form-title {
            color: #007bff;
            border-bottom: 2px solid #007bff;
            padding-bottom: 0.5rem;
            margin-bottom: 1.5rem;
            font-size: 24px;
            font-weight: bold;
        }

        .form-label {
            font-weight: 500;
            color: #555;
        }

        .form-control {
            border-radius: 8px;
            box-shadow: none;
            padding: 10px;
            font-size: 16px;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            border-radius: 8px;
            padding: 10px 20px;
            font-size: 16px;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004085;
        }

        .row.mb-3 .col-md-6, .row.mb-3 .col-md-4 {
            margin-bottom: 1rem;
        }

        .form-container select,
        .form-container input,
        .form-container textarea {
            border-radius: 8px;
            padding: 10px;
            font-size: 16px;
        }

        .form-container button[type="submit"] {
            width: 100%;
        }

        @media (max-width: 768px) {
            .form-container {
                padding: 1rem;
            }

            .form-title {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Same header/navigation as dashboard.php -->

    <div class="container">
        <div class="form-container">
            <h2 class="form-title">Register New Property</h2>
            <form action="save_property.php" method="POST">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Property Type</label>
                        <select class="form-select" name="property_type" required>
                            <option value="">Select</option>
                            <option value="Residential">Residential</option>
                            <option value="Commercial">Commercial</option>
                            <option value="Agricultural">Agricultural</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Property Area (sq ft)</label>
                        <input type="number" class="form-control" name="area" required>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Full Address</label>
                    <textarea class="form-control" name="address" rows="3" required></textarea>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Village/Town</label>
                        <input type="text" class="form-control" name="village" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">District</label>
                        <input type="text" class="form-control" name="district" value="Maharashtra" readonly>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Pincode</label>
                        <input type="number" class="form-control" name="pincode" required>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">Submit Registration</button>
            </form>
        </div>
    </div>
    
    <!-- Same footer as dashboard.php -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
