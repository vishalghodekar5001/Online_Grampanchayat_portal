<!DOCTYPE html>
<html>

<head>
  <title>Check Bill Form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body {
      background-color: #f5e8e2;
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    .container {
      margin: 20px auto;
      max-width: 800px;
      padding: 15px;
      background-image: linear-gradient(45deg, #9ad3f1, #eee8cd);
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
    }

    h1 {
      text-align: center;
    }

    form {
      display: grid;
      grid-gap: 10px;
      grid-template-columns: 1fr 1fr;
      margin-bottom: 20px;
    }

    label {
      font-weight: bold;
    }

    input[type=text],
    input[type=number] {
      padding: 10px;
      border-radius: 5px;
      border: none;
      box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
    }

    select {
      padding: 10px;
      border-radius: 5px;
      border: none;
      box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
    }

    button {
      height: 50px;
      width: 80px;
      text-align: center;
      margin-left: 300px;
    }

    /* Style the navigation bar */
    nav {
      background-color: #333;
      overflow: hidden;
      justify-content: flex-end;
    }

    /* Style the links inside the navigation bar */
    nav a {
      float: left;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
      font-size: 17px;
    }

    /* Change the color of links on hover */
    nav a:hover {
      background-color: #ddd;
      color: black;
    }

    /* Active link */
    .active {
      background-color: #4CAF50;
    }

    .user-table {
        width: 100%;
        border-collapse: collapse;
    }

    .user-table th,
    .user-table td {
        padding: 8px;
        border: 1px solid #ddd;
        text-align: left;
    }

    .user-table th {
        background-color: #f2f2f2;
    }

    .user-table {
        background-color: #f9f9f9;
    }

    .user-table tr:hover {
        background-color: #f2f2f2;
    }
  </style>
</head>

<body>

  <nav>
    <a href="admin_home.php">Dashboard</a>
  </nav>

  <!-- Add content here -->



  <div class="container">
    <h1> Grampanchayat Users Database </h1>
  </div>
  <div style="margin:20px;padding:10px;">
  <?php

  $server = "localhost";
  $username = "root";
  $password = "";
  $database = "grampanchayt";

  $conn = mysqli_connect($server, $username, $password, $database);
  if ($conn) {
    $sql = "SELECT * FROM `login_accounts`";
    $result = mysqli_query($conn, $sql);
    echo "<table class='user-table'>";
    echo "
          <tr>
              <th>User Id</th>
              <th>Resident's Name</th>
              <th>Mobile Number</th>
              <th>Email Id</th>
              <th>Password</th>
              <th>Confirm Password</th>
              <th>User Type</th>
          </tr>
          ";
    while ($row = mysqli_fetch_assoc($result)) {
        $user_id = $row['id'];
        $Residents_Name = $row['Residents_Name'];
        $Mobile_No = $row['mobile_number'];
        $Email_Id = $row['email'];
        $Password = $row['Password'];
        $Cpassword = $row['Cpassword'];
        $user_type = $row['user_type'];
        echo "<tr>
                <td>$user_id</td>
                <td>$Residents_Name</td>
                <td>$Mobile_No</td>
                <td>$Email_Id</td>
                <td>$Password</td>
                <td>$Cpassword</td>
                <td>$user_type</td>
              </tr>";
    }
    echo "</table>";

} else {
    die(mysqli_connect_error());
}

  ?>
</div>
</body>

</html>