<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard | Grampanchayat Portal</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2e7d32;
            --primary-light: #4caf50;
            --primary-dark: #1b5e20;
            --secondary: #ff9800;
            --light: #f5f5f5;
            --dark: #333;
            --gray: #757575;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --sidebar-width: 250px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f0f2f5;
            color: var(--dark);
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            background-color: var(--white);
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            height: 100vh;
            transition: all 0.3s;
            z-index: 100;
        }

        .sidebar-header {
            padding: 20px;
            background-color: var(--primary);
            color: var(--white);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .sidebar-header h3 {
            font-size: 1.3rem;
            margin-left: 10px;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .sidebar-menu li {
            list-style: none;
            margin-bottom: 5px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: var(--dark);
            transition: all 0.3s;
            font-weight: 500;
        }

        .sidebar-menu a:hover, .sidebar-menu a.active {
            background-color: rgba(46, 125, 50, 0.1);
            color: var(--primary);
            border-left: 4px solid var(--primary);
        }

        .sidebar-menu a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main Content Area */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            transition: all 0.3s;
        }

        /* Top Navigation */
        .top-nav {
            background-color: var(--white);
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow);
            position: sticky;
            top: 0;
            z-index: 90;
        }

        .search-bar {
            display: flex;
            align-items: center;
            background-color: var(--light);
            border-radius: 4px;
            padding: 8px 15px;
            width: 300px;
        }

        .search-bar input {
            border: none;
            background: transparent;
            width: 100%;
            padding: 5px;
            outline: none;
        }

        .search-bar i {
            color: var(--gray);
            margin-right: 10px;
        }

        .user-profile {
            display: flex;
            align-items: center;
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            object-fit: cover;
        }

        .user-info h4 {
            font-size: 0.9rem;
            margin-bottom: 2px;
        }

        .user-info p {
            font-size: 0.8rem;
            color: var(--gray);
        }

        /* Dashboard Content */
        .dashboard-content {
            padding: 25px;
        }

        .welcome-banner {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: var(--white);
            padding: 30px;
            border-radius: 8px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .welcome-text h2 {
            font-size: 1.8rem;
            margin-bottom: 10px;
        }

        .welcome-text p {
            opacity: 0.9;
        }

        .quick-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background-color: var(--white);
            border-radius: 8px;
            padding: 20px;
            box-shadow: var(--shadow);
            display: flex;
            align-items: center;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 1.2rem;
        }

        .stat-icon.pending {
            background-color: rgba(255, 152, 0, 0.2);
            color: var(--secondary);
        }

        .stat-icon.approved {
            background-color: rgba(46, 125, 50, 0.2);
            color: var(--primary);
        }

        .stat-icon.rejected {
            background-color: rgba(244, 67, 54, 0.2);
            color: #f44336;
        }

        .stat-info h3 {
            font-size: 1.8rem;
            margin-bottom: 5px;
        }

        .stat-info p {
            color: var(--gray);
            font-size: 0.9rem;
        }

        /* Recent Applications */
        .dashboard-section {
            background-color: var(--white);
            border-radius: 8px;
            padding: 25px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .section-header h3 {
            font-size: 1.3rem;
            color: var(--primary-dark);
        }

        .section-header a {
            color: var(--primary);
            font-weight: 500;
            font-size: 0.9rem;
        }

        .applications-table {
            width: 100%;
            border-collapse: collapse;
        }

        .applications-table th, .applications-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .applications-table th {
            font-weight: 600;
            color: var(--gray);
            font-size: 0.9rem;
        }

        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
        }

        .status-badge.pending {
            background-color: rgba(255, 152, 0, 0.1);
            color: var(--secondary);
        }

        .status-badge.approved {
            background-color: rgba(46, 125, 50, 0.1);
            color: var(--primary);
        }

        .status-badge.rejected {
            background-color: rgba(244, 67, 54, 0.1);
            color: #f44336;
        }

        .action-btn {
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 0.8rem;
            background-color: var(--primary);
            color: var(--white);
            border: none;
            cursor: pointer;
            transition: all 0.3s;
        }

        .action-btn:hover {
            background-color: var(--primary-dark);
        }

        /* Quick Actions */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
        }

        .action-card {
            background-color: var(--white);
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            box-shadow: var(--shadow);
            transition: all 0.3s;
            cursor: pointer;
        }

        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        .action-card i {
            font-size: 1.8rem;
            color: var(--primary);
            margin-bottom: 15px;
        }

        .action-card h4 {
            font-size: 1rem;
            margin-bottom: 5px;
        }

        .action-card p {
            font-size: 0.8rem;
            color: var(--gray);
        }

        /* Responsive Design */
        @media (max-width: 992px) {
            .sidebar {
                width: 70px;
                overflow: hidden;
            }

            .sidebar-header h3, .sidebar-menu a span {
                display: none;
            }

            .sidebar-menu a {
                justify-content: center;
                padding: 15px 0;
            }

            .sidebar-menu a i {
                margin-right: 0;
                font-size: 1.2rem;
            }

            .main-content {
                margin-left: 70px;
            }
        }

        @media (max-width: 768px) {
            .quick-stats {
                grid-template-columns: 1fr;
            }

            .welcome-banner {
                flex-direction: column;
                text-align: center;
            }

            .welcome-text {
                margin-bottom: 20px;
            }

            .search-bar {
                width: 200px;
            }
        }

        @media (max-width: 576px) {
            .top-nav {
                flex-direction: column;
                padding: 15px;
            }

            .search-bar {
                width: 100%;
                margin-bottom: 15px;
            }

            .user-profile {
                width: 100%;
                justify-content: flex-end;
            }

            .dashboard-content {
                padding: 15px;
            }
        }
        .action-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            padding: 0 1rem;
            margin-bottom: 3rem;
        }
        
        .action-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: var(--card-shadow);
            transition: transform 0.3s ease;
            border: none;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        
        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        }
        
        .action-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: var(--secondary-color);
        }
        
        .action-card.btn-primary .action-icon {
            color: white;
        }
        
        .action-title {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--primary-color);
        }
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-landmark"></i>
            <h3>Grampanchayat</h3>
        </div>
        <ul class="sidebar-menu">
            <li><a href="#" class="active"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a></li>
            <li><a href="#"><i class="fas fa-user"></i> <span>Profile</span></a></li>
            <li><a href="#"><i class="fas fa-file-alt"></i> <span>Applications</span></a></li>
            <li><a href="#"><i class="fas fa-certificate"></i> <span>Certificates</span></a></li>
            <li><a href="#"><i class="fas fa-comment"></i> <span>Complaints</span></a></li>
            <li><a href="#"><i class="fas fa-bell"></i> <span>Notifications</span></a></li>
            <li><a href="#"><i class="fas fa-cog"></i> <span>Settings</span></a></li>
            <li><a href="login.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
        </ul>
    </aside>

    <!-- Main Content Area -->
    <main class="main-content">
        <!-- Top Navigation -->
        <nav class="top-nav">
            <div class="search-bar">
                <i class="fas fa-search"></i>
                <input type="text" placeholder="Search...">
            </div>
            <div class="user-profile">
                <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="User">
                <div class="user-info">
                    <h4>Rahul Sharma</h4>
                    <p>Villager</p>
                </div>
            </div>
        </nav>

        <!-- Dashboard Content -->
        <div class="dashboard-content">
            <!-- Welcome Banner -->
            <div class="welcome-banner">
                <div class="welcome-text">
                    <h2>Welcome back, Rahul!</h2>
                    <p>Here's what's happening with your applications and services today.</p>
                </div>
                <div>
                    <button class="action-btn">New Application</button>
                </div>
            </div>

            <!-- Quick Stats -->
            <div class="quick-stats">
                <div class="stat-card">
                    <div class="stat-icon pending">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-info">
                        <h3>5</h3>
                        <p>Pending Applications</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon approved">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-info">
                        <h3>12</h3>
                        <p>Approved Applications</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon rejected">
                        <i class="fas fa-times-circle"></i>
                    </div>
                    <div class="stat-info">
                        <h3>2</h3>
                        <p>Rejected Applications</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <div class="stat-info">
                        <h3>3</h3>
                        <p>New Notifications</p>
                    </div>
                </div>
            </div>

            <!-- Recent Applications -->
            <div class="dashboard-section">
                <div class="section-header">
                    <h3>Recent Applications</h3>
                    <a href="#">View All</a>
                </div>
                <table class="applications-table">
                    <thead>
                        <tr>
                            <th>Application ID</th>
                            <th>Service Type</th>
                            <th>Date Applied</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>#GP2023-0567</td>
                            <td>Birth Certificate</td>
                            <td>15 June 2023</td>
                            <td><span class="status-badge approved">Approved</span></td>
                            <td><button class="action-btn">Download</button></td>
                        </tr>
                        <tr>
                            <td>#GP2023-0568</td>
                            <td>Property Tax Payment</td>
                            <td>18 June 2023</td>
                            <td><span class="status-badge pending">Pending</span></td>
                            <td><button class="action-btn">View</button></td>
                        </tr>
                        <tr>
                            <td>#GP2023-0569</td>
                            <td>Water Connection</td>
                            <td>20 June 2023</td>
                            <td><span class="status-badge pending">Pending</span></td>
                            <td><button class="action-btn">View</button></td>
                        </tr>
                        <tr>
                            <td>#GP2023-0570</td>
                            <td>Ration Card Update</td>
   
                            <td>22 June 2023</td>
                            <td><span class="status-badge rejected">Rejected</span></td>
                            <td><button class="action-btn">Reapply</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="action-cards">
                <a href="add_house.php" class="text-decoration-none">
                    <div class="action-card btn btn-outline-primary">
                        <div class="action-icon">
                            <i class="fas fa-home"></i>
                        </div>
                        <h3 class="action-title">Register Property</h3>
                        <p>Add new property details</p>
                    </div>
                </a>
                
                <a href="check_bill.php" class="text-decoration-none">
                    <div class="action-card btn btn-outline-primary">
                        <div class="action-icon">
                            <i class="fas fa-file-invoice-dollar"></i>
                        </div>
                        <h3 class="action-title">Check Bill</h3>
                        <p>View current charges</p>
                    </div>
                </a>
                
                <a href="future.html" class="text-decoration-none">
                    <div class="action-card btn btn-outline-primary">
                        <div class="action-icon">
                            <i class="fas fa-credit-card"></i>
                        </div>
                        <h3 class="action-title">Pay Bill</h3>
                        <p>Make payment online</p>
                    </div>
                </a>
                
                <a href="future.html" class="text-decoration-none">
                    <div class="action-card btn btn-outline-primary">
                        <div class="action-icon">
                            <i class="fas fa-receipt"></i>
                        </div>
                        <h3 class="action-title">Download Receipt</h3>
                        <p>Get payment confirmation</p>
                    </div>
                </a>
            </div>
        </div>
               
                
            <!-- Quick Actions -->
            <div class="dashboard-section">
                <div class="section-header">
                    <h3>Quick Actions</h3>
                </div>
                <div class="quick-actions">
                    <div class="action-card">
                        <i class="fas fa-baby"></i>
                        <h4>Birth Certificate</h4>
                        <p>Apply for new birth certificate</p>
                    </div>
                    <div class="action-card">
                        <i class="fas fa-home"></i>
                        <h4>Property Tax</h4>
                        <p>Pay property tax online</p>
                    </div>
                    <div class="action-card">
                        <i class="fas fa-tint"></i>
                        <h4>Water Bill</h4>
                        <p>Pay water bill online</p>
                    </div>
                    <div class="action-card">
                        <i class="fas fa-comment"></i>
                        <h4>Complaint</h4>
                        <p>Register a new complaint</p>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>
</html>