<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require 'phpmailer/src/Exception.php';
    require 'phpmailer/src/PHPMailer.php';
    require 'phpmailer/src/SMTP.php';

    session_start();
    $found = false;


    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "grampanchayt";

    $conn = mysqli_connect($server, $username, $password, $database);
    if (!$conn) {
    die(mysqli_connect_error());
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $registration_id = $_POST['user_id'];

        // Validate and sanitize input data if needed
        if (!ctype_digit($user_id)) {
            echo "<script>alert('Please enter a valid registration ID.');</script>";
            echo "<script>window.location = 'generate_bill.php';</script>"; // Redirect back to the form page
            exit(); // Stop further execution if validation fails
        }

        $sql = "SELECT * FROM `registered_properties` WHERE registration_id='$user_id'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $property_type = $row['property_type'];
            $house_type = $row['house_type'];
            $water_connection = $row['water_connection'];
            $user_id = $row['user_id'];
            $resident_name = $row['resident_name'];
            $survey_gat_number = $row['survey_gat_number'];
            $east_west = $row['east_west'];
            $north_south = $row['north_south'];
            $total_area = $row['total_area'];

            // Handle different scenarios based on property and house types
            switch ($property_type) {
            case "Plot":
                $property_tax = ($total_area * 5);
                $water_tax = $water_connection * 200;
                $total_tax = $property_tax + $water_tax;

                $add = "INSERT INTO tax_details (registration_id, user_id, resident_name, survey_gat_number, property_type, house_type, east_west, north_south, total_area, water_connection, property_tax, water_tax, total_tax)
                VALUES ('$registration_id', '$user_id', '$resident_name', '$survey_gat_number', '$property_type', '$house_type', '$east_west', '$north_south', '$total_area', '$water_connection', '$property_tax', '$water_tax', '$total_tax')";
                $bill = mysqli_query($conn, $add);
                if(!$bill){
                    echo "Data not inserted".mysqli_error($conn);
                }
                $found = true;
                break;
            case "House":
                switch ($house_type) {
                case "Stone-Soil Kutcha House":
                    $property_tax = ($total_area * 7);
                    $water_tax = $water_connection * 200;
                    $total_tax = $property_tax + $water_tax;

                    $add = "INSERT INTO tax_details (registration_id, user_id, resident_name, survey_gat_number, property_type, house_type, east_west, north_south, total_area, water_connection, property_tax, water_tax, total_tax)
                    VALUES ('$registration_id', '$user_id', '$resident_name', '$survey_gat_number', '$property_type', '$house_type', '$east_west', '$north_south', '$total_area', '$water_connection', '$property_tax', '$water_tax', '$total_tax')";
                    $bill = mysqli_query($conn, $add);
                    if(!$bill){
                        echo "Data not inserted".mysqli_error($conn);
                    }
                    $found = true;
                    break;
                case "Cement Concrete Pakka House":
                    $property_tax = ($total_area * 9);
                    $water_tax = $water_connection * 200;
                    $total_tax = $property_tax + $water_tax;

                    $add = "INSERT INTO tax_details (registration_id, user_id, resident_name, survey_gat_number, property_type, house_type, east_west, north_south, total_area, water_connection, property_tax, water_tax, total_tax)
                    VALUES ('$registration_id', '$user_id', '$resident_name', '$survey_gat_number', '$property_type', '$house_type', '$east_west', '$north_south', '$total_area', '$water_connection', '$property_tax', '$water_tax', '$total_tax')";
                    $bill = mysqli_query($conn, $add);
                    if(!$bill){
                        echo "Data not inserted".mysqli_error($conn);
                    }
                    $found = true;                    
                    break;
                case "R.C.C":
                    $property_tax = ($total_area * 9);
                    $water_tax = $water_connection * 300;
                    $total_tax = $property_tax + $water_tax;

                    $add = "INSERT INTO tax_details (registration_id, user_id, resident_name, survey_gat_number, property_type, house_type, east_west, north_south, total_area, water_connection, property_tax, water_tax, total_tax)
                    VALUES ('$registration_id', '$user_id', '$resident_name', '$survey_gat_number', '$property_type', '$house_type', '$east_west', '$north_south', '$total_area', '$water_connection', '$property_tax', '$water_tax', '$total_tax')";
                    $bill = mysqli_query($conn, $add);
                    if(!$bill){
                        echo "Data not inserted".mysqli_error($conn);
                    }
                    $found = true;                    
                    break;
                case "Patra / Zopdi":
                    $property_tax = ($total_area * 3);
                    $water_tax = $water_connection * 100;
                    $total_tax = $property_tax + $water_tax;

                    $add = "INSERT INTO tax_details (registration_id, user_id, resident_name, survey_gat_number, property_type, house_type, east_west, north_south, total_area, water_connection, property_tax, water_tax, total_tax)
                    VALUES ('$registration_id', '$user_id', '$resident_name', '$survey_gat_number', '$property_type', '$house_type', '$east_west', '$north_south', '$total_area', '$water_connection', '$property_tax', '$water_tax', '$total_tax')";
                    $bill = mysqli_query($conn, $add);
                    if(!$bill){
                        echo "Data not inserted".mysqli_error($conn);
                    }
                    $found = true;                    
                    break;
                default:
                    // Default case
                    break;
                }
                break;
            default:
                // Default case
                break;
            }

        } else {
            echo "<script>alert('Invalid registration ID.');</script>";
            echo "<script>window.location = 'generate_bill.php';</script>"; // Redirect back to the form page
            exit(); // Stop further execution if registration ID doesn't exist
        }
    }
    if ($found) {
        // Your existing code for generating the bill and setting $found to true
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'vishwanathshinde988@gmail.com';
        $mail->Password = 'sxrwhjgcnjogmpns';
        $mail->SMTPSecure = 'tls'; // Use TLS instead of SSL
        $mail->Port = 587; // Gmail SMTP port for TLS
        $mail->setFrom('vishwanathshinde988@gmail.com');
    
        // Email sending code
        // Fetch user's email based on user_id
        $sql_email = "SELECT Email_Id FROM login_accounts WHERE user_id='$user_id'";
        $result_email = mysqli_query($conn, $sql_email);
    
        if (!$result_email) {
            // Query execution failed
            echo "<script>alert('Error fetching email: " . mysqli_error($conn) . "');</script>";
        } else {
            // Query executed successfully
            if (mysqli_num_rows($result_email) > 0) {
                $row_email = mysqli_fetch_assoc($result_email);
                $email = $row_email['Email_Id'];
    
                // Email sending code
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = "House Tax and Water Bill";
                $mail->Body = "Hello $resident_name, your Property Registration Id is $registration_id. Your house tax amount is $total_tax and water amount is $water_tax. Total Bill = $total_tax.";
    
                // Send email
                if ($mail->send()) {
                    echo "<script>alert('Mail Sent Successfully.');</script>";
                } else {
                    echo "<script>alert('Error sending email: " . $mail->ErrorInfo . "');</script>";
                }
            } else {
                // No email found for the user_id
                echo "<script>alert('No email found for user ID: $user_id');</script>";
            }
        }
    }  
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Bill</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
            line-height: 1.42857143;
        }
        nav {
            display: flex;
            justify-content: start;
            align-items: center;
            padding: 15px;
            background-color: #333;
            color: #fff;
        }

        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            margin-left: 30px;
        }

        nav ul li:first-child {
            margin-left: 0;
        }

        nav ul li a {
            color: #f7eeee;
            text-decoration: none;
            font-size: 18px;
        }

        nav ul li a:hover {
            text-decoration: underline;
            color: white;
        }

        nav ul li button {
            text-align: right;
            color: white;
            border-radius: 20px;
            background: none;
            border: none;
            cursor: pointer;
        }

        nav ul li button:hover {
            text-decoration: underline;
        }

        .container {
            margin: 20px auto;
            max-width: 800px;
            padding: 20px;
            background-image: linear-gradient(45deg, #9ad7f1, #eee8cd);
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }

        h1 {
        text-align: center;
        margin-bottom: 20px;
        }

        form {
        display: grid;
        grid-gap: 10px;
        grid-template-columns: 1fr 1fr;
        margin-bottom: 20px;
        }

        label {
        font-weight: bold;
        }

        input[type=email],
        input[type=text],
        input[type=number] {
        padding: 10px;
        border-radius: 5px;
        border: none;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
        }

        select {
        padding: 10px;
        border-radius: 5px;
        border: none;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
        }

        button {
        height: 50px;
        width: 80px;
        text-align: center;
        margin-left: 300px;
        }
        .btn-danger {
            color: #fff;
            background-color: #ff3737;
            border-color: #f40000;
        }

        .user-table {
        width: 100%;
        border-collapse: collapse;
        }

        .user-table th,
        .user-table td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .user-table th {
            background-color: #f2f2f2;
        }

        /* .user-table tr:nth-child(even) {
            background-color: #f9f9f9;
        } */

        .user-table {
            background-color: #f9f9f9;
        }

        .user-table tr:hover {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <nav>
        <ul>
            <li><a href="admin_home.php">Dashboard</a></li>
        </ul>
    </nav>

    <div class="container">
        <h1>Generate Bill     </h1>
        <form method="post" action="generate_bill.php" autocomplete="off">
            <label for="registration_id">Enter Property Registration Id To Generate Bill :</label>
            <input type="text" id="registration_id" name="registration_id" required maxlength="20">

            <button class="btn btn-danger btn-sm">generate Bill</button>
        </form>
    </div>

    <div>
            <?php
            if ($found) {
                $sql = "SELECT * FROM `tax_details` WHERE registration_id='$registration_id'";
                $result = mysqli_query($conn, $sql);
                echo "<table class='user-table'>";
                echo "
                      <tr>
                          <th>Bill Id</th>
                          <th>Registration Id</th>
                          <th>User Id</th>
                          <th>Resident's Name</th>
                          <th>Survey / Gat Number</th>
                          <th>Property Type</th>
                          <th>House Type</th>
                          <th>East-West Length (ft)</th>
                          <th>North-South Length (ft)</th>
                          <th>Total Area (sqft)</th>
                          <th>Water Connections</th>
                          <th>Property Tax</th>
                          <th>Water Tax</th>
                          <th>Total Tax</th>
                      </tr>
                      ";
                while ($row = mysqli_fetch_assoc($result)) {
                    $bill_id = $row['bill_id'];
                    $registration_id = $row['registration_id'];
                    $user_id = $row['user_id'];
                    $resident_name = $row['resident_name'];
                    $survey_gat_number = $row['survey_gat_number'];
                    $property_type = $row['property_type'];
                    $house_type = $row['house_type'];
                    $east_west = $row['east_west'];
                    $north_south = $row['north_south'];
                    $total_area = $row['total_area'];
                    $water_connection = $row['water_connection'];
                    $property_tax = $row['property_tax'];
                    $water_tax = $row['water_tax'];
                    $total_tax = $row['total_tax'];
                    echo "<tr>
                            <td>$bill_id</td>
                            <td>$registration_id</td>
                            <td>$user_id</td>
                            <td>$resident_name</td>
                            <td>$survey_gat_number</td>
                            <td>$property_type</td>
                            <td>$house_type</td>
                            <td>$east_west</td>
                            <td>$north_south</td>
                            <td>$total_area</td>
                            <td>$water_connection</td>
                            <td>$property_tax</td>
                            <td>$water_tax</td>
                            <td>$total_tax</td>
                          </tr>";
                }
                echo "</table>";
            
            } else {
                die(mysqli_connect_error());
            }
            ?>
        </div>

</body>
</html>
