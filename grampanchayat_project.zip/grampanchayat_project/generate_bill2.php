<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "grampanchayt";

$conn = mysqli_connect($server, $username, $password, $database);
if ($conn) {
  session_start();
  $gram_id = $_SESSION['gramid'];
  $water_conn = 0;
  $house_sqrt = 0.0;
  $house_type = " ";
  $house_amount = 0;
  $water_amount = 0;
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $owner_name = $_POST['Owner'];
    $House_id = $_POST["house_id"];
    $email = $_POST["email"];
    $detail = false;
    $sql = "SELECT * FROM `house_details` WHERE Gram_Id='$gram_id' AND Email='$email' AND Owner_Name='$owner_name'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
      $row = mysqli_fetch_assoc($result);
      $house_type = $row['house_type'];
      $house_sqrt = $row['house_sqrft'];
      $water_conn = $row['water_connection'];

      switch ($house_type) {
        case 'Slab':
          $house_amount = ($house_sqrt * 6);
          $water_amount = $water_conn * 100;

          $add = "INSERT INTO `bill_details`(`GramId`, `HouseId`, `Email`, `Owner_Name`, `House_amount`, `Water_Amount`, `House_type`)
                      VALUES ('$gram_id','$House_id','$email','$owner_name','$house_amount','$water_amount','$house_type')";
          $bill = mysqli_query($conn, $add);
          $detail = true;
          break;
        case 'shed':
          $house_amount = $house_sqrt * 4;
          $water_amount = $water_conn * 100;
          $owner_name = $_POST['Owner'];
          $House_id = $_POST["house_id"];
          $mobno = intval($_POST["mobile_number"]);

          $add = "INSERT INTO `bill_details`(`Gramid`, `Houseid`, `Mobile_No`, `Owner_Name`, `House_amount`, `Water_Amount`, `House_type`)
                      VALUES ('$gram_id','$House_id','$mobno','$owner_name','$house_amount','$water_amount','$house_type')";
          $bill = mysqli_query($conn, $add);
          $detail = true;

          break;
      }
      if ($detail) {
        $to = "$email";
        $headers = "From:vishwanathshinde988@gmail.com";
        $msg = "Hello $owner_name your house id is $House_id" .
          "Your house tax amount is $house_amount and water amount is $water_amount.";
        $sub = "House tax and Water bill amount";
        if (mail($to, $sub, $msg, $headers)) {
          echo "<script>alert('Bill Generated Successfully,Kindly Generate anothe bill.');</script>";

        }
      }
    } else {
      echo "<script>alert('Invalid Mobile no or owner name!');</script>";

    }
  }
} else {
  die(mysqli_connect_error());
}
?>



<!DOCTYPE html>
<html>

<head>
  <title>Generate Bill Form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body {
      /* background-color:  */
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    .container {
      margin: 20px auto;
      max-width: 800px;
      padding: 20px;
      background-image: linear-gradient(45deg, #9ad7f1, #eee8cd);
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
    }

    h1 {
      text-align: center;
      margin-bottom: 20px;
    }

    form {
      display: grid;
      grid-gap: 10px;
      grid-template-columns: 1fr 1fr;
      margin-bottom: 20px;
    }

    label {
      font-weight: bold;
    }

    input[type=email],
    input[type=text],
    input[type=number] {
      padding: 10px;
      border-radius: 5px;
      border: none;
      box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
    }

    select {
      padding: 10px;
      border-radius: 5px;
      border: none;
      box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
    }

    button {
      height: 50px;
      width: 80px;
      text-align: center;
      margin-left: 300px;
    }

    /* Style the navigation bar */
    nav {
      background-color: #333;
      overflow: hidden;
      justify-content: flex-end;
    }

    /* Style the links inside the navigation bar */
    nav a {
      float: left;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
      font-size: 17px;
    }

    /* Change the color of links on hover */
    nav a:hover {
      background-color: #ddd;
      color: black;
    }

    /* Active link */
    .active {
      background-color: #4CAF50;
    }
  </style>
</head>

<body>

  <nav>
    <a href="log_home.php">Dashboard</a>
  </nav>

  <!-- Add content here -->



  <div class="container">
    <h1>Generate Bill Form</h1>
    <form method="post" action="generate_bill.php">
      <label for="house_id">House ID:</label>
      <input type="text" id="house_id" name="house_id" required>
      <!-- <label for="owner_name">Owner Name:</label>
            <input type="text" id="owner_name" name="owner_name" required> -->

      <label for="email">Email Id:</label>
      <input type="email" id="email" name="email" required>

      <label for="house_amount">Owner Name</label>
      <input type="text" id="Owner" name="Owner" required>
      <button class="btn btn-danger btn-sm" target="parent">Generate</button>

    </form>
</body>

</html>