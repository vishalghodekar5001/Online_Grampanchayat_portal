<?php
session_start();
$server = "localhost";
$username = "root";
$password = "";
$database = "grampanchayt";

// Connect
$conn = new mysqli($server, $username, $password, $database);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
  die("User not logged in.");
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM tax_details WHERE user_id = ?");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Check Your Bill</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap 5 CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f2f2f2;
      font-family: 'Segoe UI', sans-serif;
    }

    .container {
      background: white;
      padding: 30px;
      margin-top: 40px;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
      border-radius: 10px;
    }

    table {
      margin-top: 20px;
    }

    th {
      background-color: #0066cc;
      color: white;
    }

    .btn-print {
      margin-top: 20px;
    }

    nav {
      background-color: #333;
    }

    nav a {
      color: white;
      padding: 12px 16px;
      display: inline-block;
      text-decoration: none;
    }

    nav a:hover {
      background-color: #ddd;
      color: black;
    }
  </style>
</head>

<body>
  <nav>
    <a href="log_home.php">Dashboard</a>
  </nav>

  <div class="container">
    <h2 class="text-center mb-4">Your Property Tax Bill Details</h2>

    <?php if ($result->num_rows > 0): ?>
      <div id="bill-content">
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Bill ID</th>
              <th>Reg. ID</th>
              <th>Resident</th>
              <th>Survey/Gat No</th>
              <th>Property Type</th>
              <th>House Type</th>
              <th>Dimensions (ft)</th>
              <th>Area (sqft)</th>
              <th>Water Connections</th>
              <th>Property Tax</th>
              <th>Water Tax</th>
              <th>Total Tax</th>
            </tr>
          </thead>
          <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
              <tr>
                <td><?= $row['bill_id'] ?></td>
                <td><?= $row['registration_id'] ?></td>
                <td><?= $row['resident_name'] ?></td>
                <td><?= $row['survey_gat_number'] ?></td>
                <td><?= $row['property_type'] ?></td>
                <td><?= $row['house_type'] ?></td>
                <td><?= $row['east_west'] ?> x <?= $row['north_south'] ?></td>
                <td><?= $row['total_area'] ?></td>
                <td><?= $row['water_connection'] ?></td>
                <td>₹<?= $row['property_tax'] ?></td>
                <td>₹<?= $row['water_tax'] ?></td>
                <td><strong>₹<?= $row['total_tax'] ?></strong></td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
      <div class="text-center">
        <button class="btn btn-success btn-print" onclick="printBill()">Generate Bill</button>
      </div>
    <?php else: ?>
      <div class="alert alert-warning text-center">
        No bill records found for your account.
      </div>
    <?php endif; ?>
  </div>

  <script>
    function printBill() {
      var billContent = document.getElementById('bill-content').innerHTML;
      var win = window.open('', '', 'width=900,height=700');
      win.document.write('<html><head><title>Your Bill</title>');
      win.document.write('<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">');
      win.document.write('</head><body>');
      win.document.write('<div class="container mt-4">' + billContent + '</div>');
      win.document.write('</body></html>');
      win.document.close();
      win.print();
    }
  </script>
</body>

</html>
