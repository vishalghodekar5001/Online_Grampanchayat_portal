<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "grampanchayt";
$conn = mysqli_connect($server, $username, $password, $database);

if ($conn) {
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $loggedin = false;
    $login_input = $_POST["login_input"]; // Email or Mobile Number
    $password = $_POST["password"];
    $user_type = $_POST["user_type"]; // Retrieve user type from form data

    // Prevent SQL injection using prepared statements
    $stmt = $conn->prepare("SELECT * FROM `login_accounts` WHERE (`email` = ? OR `mobile_number` = ?) AND `user_type` = ?");
    if (!$stmt) {
      echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
    }
    $stmt->bind_param("sss", $login_input, $login_input, $user_type);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if user exists
    if ($result->num_rows == 1) {
      $row = $result->fetch_assoc();
      if (password_verify($password, $row['Password'])) { // Verifying hashed password
        $loggedin = true;
        session_start();
        $_SESSION['loggedin'] = true;
        $_SESSION['user_id'] = $row["user_id"];
        $_SESSION['Residents_Name'] = $row["Residents_Name"];

        // Redirect based on user type
        if ($user_type == 'Admin') {
          echo "<script>window.location.href='admin_home.php';</script>"; // Redirect admin to admin_home.php
        } else {
          echo "<script>window.location.href='log_home.php';</script>"; // Redirect other users to log_home.php
        }
      } else {
        echo "<script>alert('Invalid Password, Please check your password');</script>";
      }
    } else {
      echo "<script>alert('Invalid Credentials, Please check your username/email or password');</script>";
    }
  }
} else {
  die(mysqli_connect_error());
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <title>Gram Panchayat - Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <style>
    :root {
      --primary-color: #2c7be5;
      --secondary-color: #00d97e;
      --dark-color: #12263f;
      --light-color: #f9fbfd;
      --danger-color: #e63757;
      --warning-color: #f6c343;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f5f7fa;
      color: var(--dark-color);
    }

    .header {
      background: linear-gradient(135deg, #12263f 0%, #2c7be5 100%);
      color: white;
      padding: 15px 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .header img {
      height: 60px;
      margin: 0 20px;
    }

    .image img {
      width: 100%;
      max-width: 1100px;
      height: auto;
      border-radius: 4px;
    }

    nav {
      background-color: var(--primary-color);
      padding: 10px 0;
    }

    nav ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
      justify-content: center;
    }

    nav li {
      margin: 0 15px;
    }

    nav a {
      color: white;
      text-decoration: none;
      font-weight: 500;
      padding: 5px 10px;
      border-radius: 4px;
      transition: all 0.3s;
    }

    nav a:hover {
      background-color: rgba(255, 255, 255, 0.2);
    }

    .container {
      max-width: 500px;
      margin: 40px auto;
    }

    .login-page {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
      overflow: hidden;
    }

    .login-header {
      background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
      color: white;
      padding: 20px;
      text-align: center;
    }

    .login-header h3 {
      margin: 0;
      font-weight: 600;
    }

    .form {
      padding: 30px;
    }

    input,
    select {
      width: 100%;
      padding: 12px 15px;
      margin: 8px 0;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-family: 'Poppins', sans-serif;
      transition: all 0.3s;
    }

    input:focus,
    select:focus {
      border-color: var(--primary-color);
      box-shadow: 0 0 0 3px rgba(44, 123, 229, 0.2);
      outline: none;
    }

    button {
      background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
      color: white;
      border: none;
      padding: 12px;
      width: 100%;
      border-radius: 4px;
      cursor: pointer;
      font-weight: 500;
      font-family: 'Poppins', sans-serif;
      transition: all 0.3s;
    }

    button:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    .message {
      text-align: center;
      margin-top: 20px;
      color: #666;
    }

    .message a {
      color: var(--primary-color);
      text-decoration: none;
      font-weight: 500;
    }

    .message a:hover {
      text-decoration: underline;
    }

    span.error {
      color: var(--danger-color);
      font-size: 13px;
      margin-left: 5px;
    }

    .alert {
      margin: 20px 0;
      padding: 15px;
      border-radius: 4px;
    }

    .alert-danger {
      background-color: #fde8e8;
      color: var(--danger-color);
      border: 1px solid #f8d7da;
    }

    footer {
      background-color: var(--dark-color);
      color: white;
      padding: 20px 0;
      text-align: center;
      margin-top: 40px;
    }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                padding: 0.5rem;
            }
            
            .header img {
                height: 40px;
            }
            
            .dashboard-title {
                font-size: 1.5rem;
                margin: 1.5rem 0;
            }
            
            .action-cards {
                grid-template-columns: 1fr;
            }
        }
  </style>
</head>

<header class="header">
        <img src="https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg" alt="Government symbol" class="img-fluid">
        <div class="header-title">
            <h2>Maharashtra Rural Development Department</h2>
            <p>Resident Portal</p>
        </div>
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Seal_of_Maharashtra.svg/1200px-Seal_of_Maharashtra.svg.png" 
             alt="Government symbol" class="img-fluid">
    </header>

  <nav>
    <ul>
      <li><a href="home.html">Home</a></li>
      <li><a href="#">About</a></li>
      <li><a href="#">Services</a></li>
      <li><a href="#">Contact</a></li>
    </ul>
  </nav>

  <div class="container">
    <div class="login-page">
      <div class="login-header">
        <h3>Login Portal</h3>
      </div>
      <div class="form">
        <?php if (isset($_SESSION['error'])): ?>
          <div class="alert alert-danger">
            <?php echo $_SESSION['error'];
            unset($_SESSION['error']); ?>
          </div>
        <?php endif; ?>

        <form action="login.php" method="post" autocomplete="off" onsubmit="return validateForm()">
          <input type="text" name="login_input" id="login_input" placeholder="Enter Email or Mobile Number" />
          <br><span id="login_input_error"></span><br>
          <input type="password" name="password" id="password" placeholder="Password" />
          <br><span id="passwordd"></span><br>
          <select name="user_type" id="user_type">
            <option value="User" selected>User</option>
            <option value="Admin">Admin-Officer</option>
          </select>
          <button type="submit" style="margin-top: 20px;">Login</button>
          <p class="message">Not registered? <a href="acc.php">Create an account</a></p>
        </form>

      </div>
    </div>
  </div>

  <footer class="footer">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          © 2024. Content available on website is owned and maintained by Rural Development &amp; Panchayat Raj
          Department, Government of Maharashtra, India.
        </div>
      </div>
    </div>
  </footer>

  <script type="text/javascript">
function validateForm() {
    var login_input = document.getElementById("login_input").value;
    var password = document.getElementById("password").value;
    var user_type = document.getElementById("user_type").value; // Retrieve user type

    // Validate login input (email or mobile number)
    if (login_input == "") {
        document.getElementById("login_input_error").innerHTML = "*Please enter email or mobile number";
        return false;
    } else {
        document.getElementById("login_input_error").innerHTML = "";
    }

    // Validate password
    if (password == "") {
        document.getElementById("passwordd").innerHTML = "*Please enter your password";
        return false;
    } else {
        document.getElementById("passwordd").innerHTML = "";
    }

    // Validate user type
    if (user_type == "") {
        alert("Please select user type");
        return false;
    }

    return true;
}

    // Add focus effects
    document.querySelectorAll('input, select').forEach(element => {
      element.addEventListener('focus', function() {
        this.style.borderColor = '#2c7be5';
      });

      element.addEventListener('blur', function() {
        this.style.borderColor = '#ddd';
      });
    });
  </script>
</body>

</html>