<?php

$servername = "localhost";
$username = "root"; // Corrected spelling
$password = ""; // Corrected empty password
$dbname = "grampanchayt";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if(!$conn)
{
    die("Failed to connect: ".mysqli_connect_error());
}

$sql = "SELECT * FROM registered_properties";

$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) > 0)
{
    while($row = mysqli_fetch_assoc($result))
    {
        // Constructing the URL for the image
        $imagePath = '/grampanchayat_project/photo/' . $row['property_photo'];
        // Encoding the path for HTML
        $imagePathHtml = htmlspecialchars($imagePath);
        echo "<img src='".$imagePathHtml."' width='100px' height='100px'>";
    }
}
else
{
    echo "0 results";
}

mysqli_close($conn);

?>
