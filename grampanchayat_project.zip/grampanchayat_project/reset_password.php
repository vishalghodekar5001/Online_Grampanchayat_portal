<?php
require_once 'config.php';

$error = '';
$success = '';
$validToken = false;

if (isset($_GET['token'])) {
    $token = $_GET['token'];
    
    $conn = getDBConnection();
    
    // Check if token is valid and not expired
    $stmt = $conn->prepare("SELECT ResidentID FROM residents WHERE ResetToken = ? AND ResetExpires > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 1) {
        $validToken = true;
        $user = $result->fetch_assoc();
        $residentId = $user['ResidentID'];
    } else {
        $error = 'Invalid or expired reset token';
    }
    
    $stmt->close();
    closeDBConnection($conn);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $validToken) {
    $password = trim($_POST['password']);
    $confirmPassword = trim($_POST['confirm_password']);
    
    if (empty($password) || empty($confirmPassword)) {
        $error = 'Please enter and confirm your new password';
    } elseif ($password != $confirmPassword) {
        $error = 'Passwords do not match';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters long';
    } else {
        $conn = getDBConnection();
        
        // Hash the new password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Update password and clear reset token
        $stmt = $conn->prepare("UPDATE residents SET Password = ?, ResetToken = NULL, ResetExpires = NULL WHERE ResidentID = ?");
        $stmt->bind_param("si", $hashedPassword, $residentId);
        $stmt->execute();
        
        if ($stmt->affected_rows == 1) {
            $success = 'Your password has been reset successfully. You can now <a href="login.php">login</a> with your new password.';
            $validToken = false; // Token is now invalid
        } else {
            $error = 'Error updating password';
        }
        
        $stmt->close();
        closeDBConnection($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Rural Development Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome@6.4.0/css/all.min.css">
    <style>
        /* Reuse styles from login.php */
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-bg);
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        
        .login-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .login-container {
            max-width: 500px;
            margin: 3rem auto;
            padding: 2rem;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .login-title {
            color: var(--primary-color);
            font-weight: 700;
            margin-bottom: 1.5rem;
            text-align: center;
            position: relative;
        }
        
        .login-title::after {
            content: '';
            display: block;
            width: 60px;
            height: 4px;
            background: var(--accent-color);
            margin: 10px auto;
            border-radius: 2px;
        }
        
        .btn-primary {
            background-color: var(--secondary-color);
            border: none;
        }
        
        .btn-primary:hover {
            background-color: #2980b9;
        }
        
        .login-footer {
            background-color: var(--primary-color);
            color: white;
            padding: 1.5rem;
            text-align: center;
            margin-top: auto;
        }
        
        .alert {
            border-radius: 8px;
        }
        
        .password-strength {
            height: 5px;
            margin-top: 5px;
            background-color: #e9ecef;
            border-radius: 3px;
            overflow: hidden;
        }
        
        .password-strength-bar {
            height: 100%;
            width: 0%;
            transition: width 0.3s ease;
        }
    </style>
</head>
<body>
    <header class="login-header">
        <div class="container">
            <div class="d-flex justify-content-center align-items-center">
                <img src="https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg" 
                     alt="Government symbol" height="60" class="me-3">
                <div>
                    <h2>Maharashtra Rural Development Department</h2>
                    <p class="mb-0">Resident Portal</p>
                </div>
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Seal_of_Maharashtra.svg/1200px-Seal_of_Maharashtra.svg.png" 
                     alt="Government symbol" height="60" class="ms-3">
            </div>
        </div>
    </header>
    
    <main class="flex-grow-1">
        <div class="container">
            <div class="login-container">
                <h1 class="login-title">Reset Password</h1>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php elseif ($validToken): ?>
                    <form action="reset_password.php?token=<?php echo htmlspecialchars($_GET['token']); ?>" method="POST" id="resetForm">
                        <div class="mb-3">
                            <label for="password" class="form-label">New Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                            <div class="password-strength">
                                <div class="password-strength-bar" id="passwordStrengthBar"></div>
                            </div>
                            <div class="form-text">Minimum 8 characters</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                        
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Reset Password</button>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="alert alert-warning">Invalid or expired password reset link. Please request a new one.</div>
                    <div class="text-center">
                        <a href="forgot_password.php" class="btn btn-outline-primary">Request New Reset Link</a>
                    </div>
                <?php endif; ?>
                
                <div class="mt-3 text-center">
                    <a href="login.php" class="text-decoration-none">Back to Login</a>
                </div>
            </div>
        </div>
    </main>
    
    <footer class="login-footer">
        <div class="container">
            <p class="mb-0">© 2024. Content owned and maintained by Rural Development & Panchayat Raj Department, Government of Maharashtra, India.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Password strength indicator
        document.getElementById('password').addEventListener('input', function(e) {
            const password = e.target.value;
            const strengthBar = document.getElementById('passwordStrengthBar');
            let strength = 0;
            
            // Length check
            if (password.length >= 8) strength += 25;
            if (password.length >= 12) strength += 25;
            
            // Character type checks
            if (password.match(/[a-z]/)) strength += 10;
            if (password.match(/[A-Z]/)) strength += 10;
            if (password.match(/[0-9]/)) strength += 10;
            if (password.match(/[^a-zA-Z0-9]/)) strength += 20;
            
            // Update strength bar
            strengthBar.style.width = strength + '%';
            
            // Update color
            if (strength < 50) {
                strengthBar.style.backgroundColor = '#dc3545'; // Red
            } else if (strength < 75) {
                strengthBar.style.backgroundColor = '#ffc107'; // Yellow
            } else {
                strengthBar.style.backgroundColor = '#28a745'; // Green
            }
        });
    </script>
</body>
</html>