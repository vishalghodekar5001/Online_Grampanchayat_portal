<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id'])) {
    header('location:login.php');
    exit;
}

$user_id = $_SESSION['user_id']; // Corrected this line (you had $id = $_SESSION['id'])

if (isset($_POST['save'])) {
    $resident_name = mysqli_real_escape_string($con, $_POST['resident_name']);
    $survey_gat_number = mysqli_real_escape_string($con, $_POST['survey_gat_number']);
    $property_type = mysqli_real_escape_string($con, $_POST['property_type']);
    $house_type = mysqli_real_escape_string($con, $_POST['house_type']);
    $east_west = floatval($_POST['east_west']);
    $north_south = floatval($_POST['north_south']);
    $total_area = floatval($_POST['total_area']);
    $water_connection = intval($_POST['water_connection']);
    $property_registration_date = date('Y-m-d');

    // Upload property photo
    $picname = "";
    if (isset($_FILES['property_photo']) && $_FILES['property_photo']['error'] == 0) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $picname = time() . "_" . basename($_FILES['property_photo']['name']); // Safer to add timestamp
        $target_file = $target_dir . $picname;
        move_uploaded_file($_FILES['property_photo']['tmp_name'], $target_file);
    }

    // Insert into database
    $sql = "INSERT INTO registered_properties 
        (user_id, resident_name, survey_gat_number, property_type, house_type, east_west, north_south, total_area, water_connection, property_photo, property_registration_date)
        VALUES
        ('$user_id', '$resident_name', '$survey_gat_number', '$property_type', '$house_type', $east_west, $north_south, $total_area, $water_connection, '$picname', '$property_registration_date')";

    $query = mysqli_query($con, $sql);

    if ($query) {
        echo "<script>alert('Property Registered Successfully!'); window.location='registered_property.php';</script>";
    } else {
        echo "<script>alert('Error occurred while saving!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Property</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Property Registration Form</h2>
    <form method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="resident_name" class="form-label">Resident Name</label>
            <input type="text" class="form-control" id="resident_name" name="resident_name" required>
        </div>
        <div class="mb-3">
            <label for="survey_gat_number" class="form-label">Survey/Gat Number</label>
            <input type="text" class="form-control" id="survey_gat_number" name="survey_gat_number" required>
        </div>
        <div class="mb-3">
            <label for="property_type" class="form-label">Property Type</label>
            <select class="form-select" id="property_type" name="property_type" required>
                <option value="">--Select--</option>
                <option value="Residential">Residential</option>
                <option value="Commercial">Commercial</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="house_type" class="form-label">House Type</label>
            <select class="form-select" id="house_type" name="house_type" required>
                <option value="">--Select--</option>
                <option value="Apartment">Apartment</option>
                <option value="Independent House">Independent House</option>
            </select>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="east_west" class="form-label">East-West (Length in feet)</label>
                <input type="number" step="0.01" class="form-control" id="east_west" name="east_west" required>
            </div>
            <div class="col-md-6 mb-3">
                <label for="north_south" class="form-label">North-South (Breadth in feet)</label>
                <input type="number" step="0.01" class="form-control" id="north_south" name="north_south" required>
            </div>
        </div>
        <div class="mb-3">
            <label for="total_area" class="form-label">Total Area (sqft)</label>
            <input type="number" step="0.01" class="form-control" id="total_area" name="total_area" readonly required>
        </div>
        <div class="mb-3">
            <label for="water_connection" class="form-label">Water Connection Available?</label><br>
            <select class="form-select" id="water_connection" name="water_connection" required>
                <option value="">--Select--</option>
                <option value="1">Yes</option>
                <option value="0">No</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="property_photo" class="form-label">Upload Property Photo</label>
            <input type="file" class="form-control" id="property_photo" name="property_photo" accept="image/*">
        </div>
        <button type="submit" name="save" class="btn btn-primary">Register Property</button>
    </form>
</div>

<script>
// Auto-calculate total area
function calculateArea() {
    let eastWest = parseFloat(document.getElementById('east_west').value) || 0;
    let northSouth = parseFloat(document.getElementById('north_south').value) || 0;
    let totalArea = eastWest * northSouth;
    document.getElementById('total_area').value = totalArea.toFixed(2);
}

document.getElementById('east_west').addEventListener('input', calculateArea);
document.getElementById('north_south').addEventListener('input', calculateArea);
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
