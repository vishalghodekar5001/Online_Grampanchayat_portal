 <?php
$server = "localhost";
$username = "root";
$password = "";
$database = "grampanchayt";
$conn = mysqli_connect($server, $username, $password, $database);
if ($conn) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $loggedin = false;
        $owner_name = $_POST["owner_name"];
        $password = $_POST["password"];
        $user_type = $_POST["user_type"]; // Retrieve user type from form data

        // Prevent SQL injection using prepared statements
        //$stmt = $conn->prepare("SELECT * FROM `login_accounts` WHERE `Residents_Name`=? AND `Password`=? AND `user_type`=?");
        $stmt = $conn->prepare("SELECT `id`, `user_type` FROM login_accounts WHERE Email_Id=? AND Password=?");

        if (!$stmt) {
            echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
        }
        $stmt->bind_param("sss", $owner_name, $password, $user_type);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if user exists
        if ($result->num_rows == 1) {
            $loggedin = true;
            session_start();
            $_SESSION['loggedin'] = true;

            // Fetch and store the GramId in session
            $stmt = $conn->prepare("SELECT `user_id`, `Residents_Name` FROM `login_accounts` WHERE `Residents_Name`=?");
            if (!$stmt) {
                echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
            }
            $stmt->bind_param("s", $owner_name);
            $stmt->execute();
            $gramid_result = $stmt->get_result();
            $row = $gramid_result->fetch_assoc();
            $_SESSION['user_id'] = $row["user_id"];
            $_SESSION['Residents_Name'] = $row["Residents_Name"];

            if ($user_type == 'Admin') {
                echo "<script>window.location.href='admin_home.php';</script>"; // Redirect admin to admin_home.php
            } else {
                echo "<script>window.location.href='log_home.php';</script>"; // Redirect other users to log_home.php
            }
        } else {
            echo "<script>alert('Invalid Credentials, Please check username password');</script>";
        }
    }
} else {
    die(mysqli_connect_error());
}
?> 

<!DOCTYPE html>
<html>

<head>
  <title>Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="login.css">
  <link rel="stylesheet" href="style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script type="text/javascript">
    function validateForm() {
        var owner_name = document.getElementById("owner_name").value;
        var password = document.getElementById("password").value;
        var user_type = document.getElementById("user_type").value; // Retrieve user type

        if(owner_name == "") {
          document.getElementById("owner_namee").innerHTML="*Please enter resident's name";
          return false;
        } else {
          document.getElementById("owner_namee").innerHTML="";
        }

        if(password == "") {
          document.getElementById("passwordd").innerHTML="*Please enter your password";
          return false;
        } else {
          document.getElementById("passwordd").innerHTML="";
        }

        if(user_type == "") {
          alert("Please select user type");
          return false;
        }

        return true;
    }
  </script>
</head>

<body>
  <header class="header">
    <img src="https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg" alt="Government symbol">
    <div class="image">
      <img style="width:1100px" ; height="100%"
        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8MWORO6pzmivILU-Pbm-LrZuB-Tt2dhatYwNIkOLWocFxqEsrrr-DwSd6M7R0hMYpiw&usqp=CAU">
    </div>
    <img
      src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Seal_of_Maharashtra.svg/1200px-Seal_of_Maharashtra.svg.png"
      alt="Government symbol">
  </header>

  <nav>
    <ul>
      <li><a href="home.html">Home</a></li>
    </ul>
  </nav>

  <div class="container">
    <div class="login-page">
      <div class="form">
        <div class="login">
          <div class="login-header">
            <h3 style="text-align: center;">Login</h3>
          </div>
        </div>
        <form action="login.php" method="post" autocomplete="off" onsubmit="return validateForm()">
          <input type="text" name="owner_name" id="owner_name" placeholder="Resident's Name"/>
			    <br><span id="owner_namee"></span><br>
          <input type="password" name="password" id="password" placeholder="Password"/>
			    <br><span id="passwordd"></span><br>
          <select name="user_type" id="user_type" style="width:270px;">
            <option value="User" selected>User</option>
            <option value="Admin">Admin-Officer</option>
          </select>
          <button type="submit" style="margin-top: 20px;">Login</button>
          <p class="message">Not registered?
          <a href="acc.php">Create an account</a></p>
        </form>
      </div>
    </div>
  </div>

  <footer class="footer">
    <div class="container">
      <div class="row">
        <div class="col-md-12" style="text-align:center;">
          © 2024. Content available on website is owned and maintained by Rural Development &amp; Panchayat Raj
          Department, Government of Maharashtra, India.
        </div>
      </div>
    </div>
  </footer>

</body>

</html> 



<!-- dash page -->


<!-- 
<!DOCTYPE html>
<html>

<head>
    <title>Project Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="log_home.css">
    <style>
        h1 {
            padding: 20px;
            background-color: #fff;
            border-radius: 20px;
            color: rgb(195, 86, 62);
            width: 250px;
            text-align: center;
            margin-left: 650px;
            margin-top: 20px;
            border: 3px solid black;
        }
    </style>



</head>

<body>

    <header class="header">
        <img src="https://upload.wikimedia.org/wikipedia/commons/5/55/Emblem_of_India.svg" alt="Government symbol">
        <div class="image">
            <img style="width:1100px" ; height="100%"
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8MWORO6pzmivILU-Pbm-LrZuB-Tt2dhatYwNIkOLWocFxqEsrrr-DwSd6M7R0hMYpiw&usqp=CAU">

        </div>
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Seal_of_Maharashtra.svg/1200px-Seal_of_Maharashtra.svg.png"
            alt="Government symbol">
    </header>
    <nav>
        <ul>
            <li><a href="home.html">Logout</a></li>
        </ul>
        <img src="images/profile3.jpg" class="profile_icon" alt="Profile" onclick="toggleMenu()">

        <div class="sub-menu-wrap" id="subMenu">
            <div class="sub-menu">
                <h3>Hello <?php echo $Residents_Name; ?></h3>
            </div>
        </div>
    </nav>
    <h1>Dashboard</h1><br>
    <div class="container" style="max-width: fit-content;">
        <a href="add_house.php"><button class="btn btn-lg btn-success" target="_parent">Register Property</button></a>
        <a href="check_bill.php"><button class="btn btn-lg btn-primary" target="_parent">Check Bill</button></a>
        <a href="future.html"><button class="btn btn-lg btn-secondary" target="_parent">Pay Bill</button></a>
        <a href="future.html"><button class="btn btn-lg btn-tertionary" target="_parent">Download Receipt</button></a>
    </div>


    <div class="footer">
        <div class="container">
            <div class="row">
                <div style="text-align:center;" tabindex="0">© 2024.Content available on website is owned and maintained
                    by Rural Development &amp; Panchayat Raj Department, Government of Maharashtra, India.</div>
            </div>
        </div>
    </div>
    </div>

    <script>
        let subMenu = document.getElementById("subMenu");

        function toggleMenu(){
            subMenu.classList.toggle('open-menu');
        }
    </script>

</body>

</html> -->