<!DOCTYPE html>
<html>
<head>
    <title>Add House Bill</title>
</head>
<body>
    <h1>Add House Bill</h1>
    <?php
        // check if form submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // get form data
            $house_number = $_POST["house_number"];
            $tax_amount = $_POST["tax_amount"];
            $water_bill = $_POST["water_bill"];

            // connect to database
            $servername = "localhost";
            $username = "vishal@123";
            $password = "vishal@5001";
            $dbname = "myDB";
            $conn = new mysqli($servername, $username, $password, $dbname);

            // check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // prepare and bind SQL statement
            $stmt = $conn->prepare("INSERT INTO house_bills (house_number, tax_amount, water_bill) VALUES (?, ?, ?)");
            $stmt->bind_param("sdd", $house_number, $tax_amount, $water_bill);

            // execute statement
            if ($stmt->execute() === TRUE) {
                echo "House bill added successfully.";
            } else {
                echo "Error adding house bill: " . $conn->error;
            }

            // close statement and connection
            $stmt->close();
            $conn->close();
        }
    ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="house_number">House Number:</label>
        <input type="text" id="house_number" name="house_number" required>
        <label for="tax_amount">Tax Amount:</label>
        <input type="number" id="tax_amount" name="tax_amount" min="0" step="0.01" required>
        <label for="water_bill">Water Bill:</label>
        <input type="number" id="water_bill" name="water_bill" min="0" step="0.01" required>
        <input type="submit" value="Add Bill">
    </form>
</body>
</html>
